<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
    class FactureDB extends Model{
		
		//La base de données samane_test est dans view/test
		//Pour tester importer la 
        public function __construct(){
            parent::__construct();
        }

        public function getFactID($ID)
        {
            $sql = "SELECT * FROM facture
                     WHERE facture.idFacture = ".$ID;
            if($this->db != null)
			{
				return $this->db->query($sql)->fetch();
			}else{
				return null;
			}
		}
		public function getAbID($ID)
        {
            $sql = "SELECT * FROM abonnement
                     WHERE abonnement.idAbonnement = ".$ID;
            if($this->db != null)
			{
				return $this->db->query($sql)->fetch();
			}else{
				return null;
			}
        }

		
		public function addFact($mois,$consommation,$prix,$reglement,$idAbonnement){
			$sql = "INSERT INTO facture VALUES(null,'$mois','$consommation','$prix','$reglement','$idAbonnement')";
			if($this->db != null)
			{
				$this->db->exec($sql);
				return $this->db->lastInsertId();//Si la clé primaire est auto_increment
											 //sinon return $this->db->exec($sql);
			}else{
				return null;
			}
		}
		
		public function deleteFact($idFacture){
			$sql = "DELETE FROM facture WHERE idFacture = $idFacture";

			if($this->db != null)
			{
				return $this->db->exec($sql);
			}else{
				return null;
			}
		}
		
        public function updateFact($idFacture,$consommation,$prix,$reglement)
		{
			$sql = "UPDATE facture SET consommation = '$consommation',
			                              prix = $prix,
										  reglement=$reglement
						
						WHERE idFacture = $idFacture";

			if($this->db != null)
			{
				return $this->db->exec($sql);
			}else{
				return null;
			}
		}
		
		public function listeFact(){
			$sql = "SELECT * FROM facture";
			
			if($this->db != null)
				return $this->db->query($sql)->fetchAll();
			else
				return null;
        }
		public function listeAbon(){
			$sql = "SELECT * FROM abonnement";
			
			if($this->db != null)
				return $this->db->query($sql)->fetchAll();
			else
				return null;
        }

       


	}

	