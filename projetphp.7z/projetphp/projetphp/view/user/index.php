<html>
	<head>
		<meta charset="UTF-8">
		<title>page d'accueil</title>
		<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}

			.logosenelec{
				margin-left:10px;
				margin-top:50px;
				width:65px;
				 height:65px;
				

			}             
			 .ic_user{

				 margin-left:250px;
				 width:150px;
				 height:150px;
			 }

		</style>
	</head>
	<body>
		
	<img src="{$url_base}public/image/logosen2.jpg" class="logosenelec">

	
		<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:50px;">
			<div class="panel panel-info">
				<div class="panel-heading">BIENVENUE </div>
				<div class="panel-body">
				
				<img src="{$url_base}public/image/user.png" class="ic_user">

				{if isset($ok)}
						{if $ok != 0}
							<div class="alert alert-success">  </div>
						{else}
							<div class="alert alert-danger"> email ou mot de pass incorrecte</div>
						{/if}
					{/if}
					<form method="post" action="{$url_base}User/GetConnection">
						

						<div class="form-group">
									<label class="control-label">EMAIL</label>
									<input class="form-control" type="email" name="email" id="email" required/>
						</div>

                  			  <div class="form-group">
									<label class="control-label">PASSWORD</label>
									<input class="form-control" type="password" name="password" id="password" required/>
								</div>

						  
								<div class="form-group">
							<input class="btn btn-success" type="submit" name="connexion" value="connexion"/>
							</div>
							
						
					</form>
				</div>
			</div>
		</div>
		
	</body>
</html>
		
