<html>
	<head>
		<meta charset="UTF-8">
		<title>page liste</title>
		<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}
		</style>
	</head>
	<body>
		
		<div class="nav navbar navbar-default navbar-fixed-top">
		<ul class="nav navbar-nav">
				<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
				<li><a href="{$url_base}Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="{$url_base}Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="{$url_base}Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="{$url_base}Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		<div class="col-md-6 col-xs-6 col-md-6" style="margin-top:70px;">
			<div class="panel panel-primary">
				<div class="panel-heading">NUMEROS COMPTEUR DISPONIBLES</div>
				<div class="panel-body">
			
					{if isset($tests)}
						{if $tests != null}
							<table class="table table-bordered table-stripped">
								<tr>
									
									<th>numero</th>
									
								</tr>
								{foreach from=$tests item=test}
									<tr>
										
										<td>{$test['numero']}</td>
										
										
										<td><a href="{$url_base}Abonnement/choix/{$test['numero']}">Choisir </a></td>
									</tr>
								{/foreach}
							</table>
						{else}
							Liste vide
						{/if}
					{/if}
				</div>
				
			</div>
		</div>
		<!----------------formulaire abonnement------------------>

		<div class="col-md-6 col-xs-6 col-md-6" style="margin-top:70px;">
			<div class="panel panel-primary">
				<div class="panel-heading">FORMULAIRE D'ABONNEMENT</div>
				<div class="panel-body">
				{if isset($ok)}
						{if $ok != 0}
							<div class="alert alert-success">Données ajoutées! votre numéro de compteur est : {if isset($test)} {$test['numero']} {/if} </div>
						{else}
							<div class="alert alert-danger">Erreur!! cumul Ancien et cumul Nouveau doivent être des chiffres</div>
						{/if}
					{/if}
					<form method="post" action="{$url_base}Abonnement/add">
						<div class="form-group">
							<label class="control-label">Contrat</label>
							<input class="form-control" type="text" name="contrat" id="contrat" required/>
						</div>
						<div class="form-group">
								<label class="control-label">date</label>
								<input class="form-control" type="date" name="date" id="date" required/>
							</div>

							<div class="form-group">
							<label class="control-label">Cumul Ancien</label>
							 <h1> <select name="cumulAncien" id="cumulAncien" class="form-control">
								<option value=0> 0 </option>
							 </select> </h1>
						</div>

						<div class="form-group">
							<label class="control-label">Cumul Nouveau</label>
							 <h1> <select name="cumulNouveau" id="cumulNouveau" class="form-control">
								<option value=0> 0 </option>
							 </select> </h1>
						</div>

									<div class="form-group">
							<label class="control-label">Numero compteur</label>
							 <h1> <select name="numero" id="numero">
								<option > {if isset($test)} {$test['numero']} {/if} </option>
							 </select> </h1>
						</div>
					
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="valider" value="ENVOYER"/>
							
							<input class="btn btn-danger" type="reset" name="annuler" value="ANNULER"/>
							<a href="{$url_base}Abonnement/liste" class="btn btn-success" >AFFICHER</a>
							
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
