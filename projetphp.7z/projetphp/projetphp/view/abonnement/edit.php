<html>
	<head>
		<meta charset="UTF-8">
		<title>page Modification</title>
		<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/samane.css"/>
		<style>
			h1{ 
				color: #348ba5;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}
		</style>
	</head>
	<body>
		<img src="{$url_base}public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
		<ul class="nav navbar-nav">
				<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
				<li><a href="{$url_base}Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="{$url_base}Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="{$url_base}Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="{$url_base}Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		<div class="col-md-9 col-xs-12 col-md-offset-1" style="margin-top:60px;">
			<div class="panel panel-primary">
				<div class="panel-heading">MODIFICATION</div>
				<div class="panel-body">
			
					<form method="post" action="{$url_base}Abonnement/update">
						<div class="form-group">
							<label class="control-label">ID abonnement</label>
							 <h1> <select name="idAbonnement" id="idAbonnement">
								<option > {if isset($test)} {$test['idAbonnement']} {/if} </option>
							 </select> </h1>
						</div>
						<div class="form-group">
							<label class="control-label">Contrat</label>
							<input class="form-control" type="text" name="contrat" id="contrat" value="{if isset($test)} {$test['contrat']} {/if}"/>
						</div>
                        <div class="form-group">
								<label class="control-label">date d'abonnement</label>
								 <h1> <select name="date" id="date">
									<option value=""> {if isset($test)} {$test['date']} {/if} </option>
								
								 </select> </h1>
							</div>
                        <div class="form-group">
								<label class="control-label">Cumul Ancien</label>
								<select class="form-control" type="number" step="any" name="cumulAncien" id="cumulAncien">
                                 <option value="{if isset($test)} {$test['cumulNouveau']} {/if}"> {if isset($test)} {$test['cumulNouveau']} {/if}</option>
								</select> 
							</div>
							<div class="form-group">
									<label class="control-label">CumulNouveau</label>
									<input class="form-control" type="number" step="any" name="cumulNouveau" id="cumulNouveau" placeholder="Ecrire le nouveau cumul" />
								</div>
								

						
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="modifier" value="Modifier"/>
							<a class="btn btn-primary" href="{$url_base}Abonnement/liste">Retour</a>
							
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>