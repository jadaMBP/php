<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>page d'accueil</title>
		<style>
		#design_error{
			font-size : 22px;
			color : red;
			margin-top: 500px;
			margin: auto;
			height:75px;
			background-color: #FFBD4F;
		}
		</style>
	</head>
	<body>
		<div>
			<div id="design_error">Arretez, vous n'avez pas les droits d'acces à cette page !</div>
		</div>
	</body>
</html>