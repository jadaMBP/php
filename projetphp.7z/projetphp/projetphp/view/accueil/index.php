<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>page d'accueil</title>
		<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/samane.css"/>
		<!-- integration de javascript dans le moteur de rendu de vue Smarty -->
		{literal}
			<script language=javascript>
			 function load_design() {
			   document.getElementById("design_js").style.color = "#40007d";
			 }
               
			</script>
		{/literal}
		<style>
			
			
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}

            .panel-body {
                 background-color:#28afeb;
                 border:1px solid #9FC6FF;
                 padding:5px;
           /*arrondir les coins en haut à gauche et en bas à droite*/
           -moz-border-radius:10px 0;
            -webkit-border-radius:10px 0;
            border-radius:20px 0;
			
                }

				.panel-primary{
					border:1px solid #9FC6FF;
                 padding:5px;
           /*arrondir les coins en haut à gauche et en bas à droite*/
           -moz-border-radius:10px 0;
            -webkit-border-radius:10px 0;
            border-radius:20px 0;
			width:195px;
			margin-right:100px;
				}

				.panel-heading{
					-moz-border-radius:10px 0;
            -webkit-border-radius:10px 0;
            border-radius:20px 0;
				}

				
                   
				   .senelecbat{
					width:1200px;
						height:300px;
						margin-top:8px;
				   }

                   .logosenelec
				   {
                        width:1200px;
						height:300px;
						margin-top:8px;
				   }
					
					.woyofal{
						width:1200px;
						height:300px;
						margin-top:9px;
					}
				  .akilee{
					width:1200px;
						height:300px;
						margin-top:9px;
				}

		</style>
	</head>
	<body onload="load_design()">

		<div class="nav navbar navbar-default navbar-fixed-top">
		<ul class="nav navbar-nav">
				<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
				<li><a href="{$url_base}Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="{$url_base}Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="{$url_base}Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="{$url_base}Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		
		<marquee behavior="Alternate" direction="">
			
			<img src="{$url_base}public/image/logosen2.jpg" class="logosenelec">
			<img src="{$url_base}public/image/senelecbat.jpg" class="senelecbat"> 
		
		</marquee>

		<div class="col-md-10 col-xs-6 col-md-10" style="margin-top:2px;" >
		
		
		<img src="{$url_base}public/image/woyofal.png" class="woyofal"> 
		<img src="{$url_base}public/image/akilee.jpg" class="akilee"> 
		<img src="{$url_base}public/image/lampe.jpg" class="akilee">
	</div>         


		

		

       
	</body>
</html>
