<html>
	<head>
		<meta charset="UTF-8">
		<title>page liste</title>
		<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}
	      
		</style>
	</head>
	<body>
		
		<div class="nav navbar navbar-default navbar-fixed-top">
			<ul class="nav navbar-nav">
				<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
				<li><a href="{$url_base}Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="{$url_base}Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="{$url_base}Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="{$url_base}Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		<div class="col-md-10 col-xs-6 col-md-18" style="margin-top:90px;">
			<div class="panel panel-primary">
				<div class="panel-heading">AFFICHAGE DES FACTURES</div>
				<div class="panel-body">
					
					{if isset($tests)}
						{if $tests != null}
							<table class="table table-bordered table-stripped">
								<tr>
									<th>Identifiant</th>
									<th>Mois</th>
									<th>Consommation</th>
									<th>Prix</th>
									<th>Reglement</th>
									<th>ID Abonnement</th>
									<th>action</th>
									<th>action</th>
									
								</tr>
								{foreach from=$tests item=test}
								
									<tr>
										<td>{$test['idFacture']}</td>
										<td>{$test['mois']}</td>
										<td>{$test['consommation']}</td>
										<td>{$test['prix']}</td>
										<td>{$test['reglement']}</td>
										<td>{$test['idAbonnement']}</td>
										
										<td><a href="{$url_base}Facture/delete/{$test['idFacture']}">Supprimer</a></td>
										<td><a href="{$url_base}Facture/edit/{$test['idFacture']}">Editer</a></td>
									</tr>
								{/foreach}
							</table>
						{else}
							Liste vide
						{/if}
					{/if}
				</div>
				
			</div>
		</div>
		<!-----------------------formulaire ajout numero compteur----->
		<div class="col-md-6 col-xs-6 col-md-2" style="margin-top:150px;">
			<div class="panel panel-primary">
				<div class="panel-heading"></div>
				<div class="panel-body">
				
				</div>
				<a href="{$url_base}Facture/liste3" class="panel-heading">RETOUR</a>
			</div>
		</div>
	</body>
</html>
