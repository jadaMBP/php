<html>
	<head>
		<meta charset="UTF-8">
		<title>page liste</title>
		<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}
		</style>
	</head>
	<body>
		
		<div class="nav navbar navbar-default navbar-fixed-top">
		<ul class="nav navbar-nav">
				<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
				<li><a href="{$url_base}Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="{$url_base}Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="{$url_base}Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="{$url_base}Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		<div class="col-md-8 col-xs-16 col-md-15" style="margin-top:55px;">
			<div class="panel panel-primary">
				<div class="panel-heading">AFFICHAGE DES COMPTEURS</div>
				<div class="panel-body">
				
					{if isset($tests)}
						{if $tests != null}
							<table class="table table-bordered table-stripped">
								<tr>
								<th>NUMERO</th>
									<th>ACTION</th>
									
									
								</tr>
								{foreach from=$tests item=test}
									<tr>
										
										<td>{$test['numero']}</td>
										
										<td><a href="{$url_base}Compteur/delete/{$test['numero']}">Supprimer</a></td>
							
									</tr>
								{/foreach}
							</table>
						{else}
							Liste vide
						{/if}
					{/if}
				</div>
				
			</div>
		</div>
		<!-----------------------bouton (mini div) ajout numero compteur----->
		<div class="col-md-6 col-xs-6 col-md-2" style="margin-top:150px;">
			<div class="panel panel-primary">
				<div class="panel-heading"></div>
				<div class="panel-body">
				
				</div>
				<a href="{$url_base}Compteur/add" class="panel-heading">Ajout d'un Compteur</a>
			</div>
		</div>
	</body>
</html>
