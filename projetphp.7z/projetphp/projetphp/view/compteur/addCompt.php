<html>
	<head>
		<meta charset="UTF-8">
		<title>page get id</title>
		<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="{$url_base}public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}
		</style>
	</head>
	<body>
		
		<div class="nav navbar navbar-default navbar-fixed-top">
		<ul class="nav navbar-nav">
				<!-- l'appel de {$url_base} vous permet de recupérer le chemin de votre site web  -->
				<li><a href="{$url_base}Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="{$url_base}Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="{$url_base}Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="{$url_base}Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:150px;">
			<div class="panel panel-primary">
				<div class="panel-heading">VOUS ALLEZ AJOUTER UN COMPTEUR!!</div>
				<div class="panel-body">
					{if isset($ok)}
						{if $ok != 0}
							<div class="alert alert-success">Bravo c'est dans le mil!</div>
						{else}
							<div class="alert alert-danger">Désolé il ya une erreur!</div>
						{/if}
					{/if}
					<form method="post" action="{$url_base}Compteur/add">
						
					
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="valider" value="AJOUTER UN COMPTEUR"/>
							
							<a class="btn btn-primary" href="{$url_base}Compteur/liste">RETOURNER A LA LISTE</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>