<?php

    class Facture extends Controller{
        public function __construct(){
            parent::__construct();
            //Appel du model
            require_once 'model/FactureDB.php';
        }

		//A noter que toutes les views de ce controller doivent être créées dans le dossier view/test
        //Ne tester pas toutes les methodes, ce controller est un prototype pour vous aider à mieux comprendre
        public function index(){
            return $this->view->load("facture/index");
        }

        public function getID($id){
            $data['idFacture'] = $id;

            return $this->view->load("facture/get_id", $data);
        }
        
        public function get($id){
            //Instanciation du model
            $tdb = new  AbonnementDB();

            $data['test'] = $tdb->getFactID($id);
			
            return $this->view->load("facture/get", $data);
        }

        public function getAB($id){
            //Instanciation du model
            $tdb = new  AbonnementDB();

            $data['abon'] = $tdb->getAbID($id);
			
            return $this->view->load("facture/get", $data);
        }
		public function liste(){
            //Instanciation du model
            $tdb = new FactureDB();
			
            $data['tests'] = $tdb->listeFact();
			
            return $this->view->load("facture/liste", $data);
        }
       
        public function Liste3(){
            //Instanciation du model
            $tdb = new FactureDB();
			
            $data['tests'] = $tdb->listeAbon();
			
            return $this->view->load("facture/liste3", $data);
        }
        public function choix($id){
			//Instanciation du model
            $tdb = new FactureDB();
            //Supression
            $data['tests'] = $tdb->listeAbon();
			$data['test'] = $tdb->getAbID($id);
			//chargement de la vue edit.html
            return $this->view->load("facture/liste3", $data);
        }

	
		public function add(){
			//Instanciation du model
            $tdb = new FactureDB();
			//Récupération des données qui viennent du formulaire view/test/add.html (à créer)
            if(isset($_POST['valider']))//'valider' est le name du champs submit du formulaire add.html
            {
                extract($_POST);
                $data['ok'] = 0;
                $boolan='oui';
                $bool=0;
               

                if(strcmp ( $reglement, $boolan)==0){
                  $bool=1;
            
                }
                $ok = $tdb->addFact($mois,$consommation,$prix,$bool,$idAbonnement);
                  $data['ok'] = $ok;   
                  return $this->liste();
            
            }else{
                return $this->view->load("facture/liste3");
            }
        }

		public function update(){
			//Instanciation du model
            $tdb = new  FactureDB();
            if(isset($_POST['modifier'])){
                extract($_POST);
                $bool=0;
                  if($reglement==="oui"){
                      $bool=1;
                  }
                    $ok = $tdb->updateFact($idFacture,$consommation,$prix,$bool);
                
            }
           
            return $this->liste();//appel de la methode liste du controller
        }

        public function delete($id){
            //Instanciation du model
            $tdb = new FactureDB();
			//Supression
			$tdb->deleteFact($id);
			//Retour vers la liste
            return $this->liste();
        }
		
		public function edit($id){
			
            //Instanciation du model
            $tdb = new FactureDB();
			//Supression
			$data['test'] = $tdb->getFactID($id);
			//chargement de la vue edit.html
            return $this->view->load("facture/edit", $data);
        }

        
    }
?>