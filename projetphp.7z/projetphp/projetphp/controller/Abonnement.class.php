<?php

    class Abonnement extends Controller{
        public function __construct(){
            parent::__construct();
            //Appel du model
            require_once 'model/AbonnementDB.php';
        }

		//A noter que toutes les views de ce controller doivent être créées dans le dossier view/test
        //Ne tester pas toutes les methodes, ce controller est un prototype pour vous aider à mieux comprendre
        
        
        public function add(){
			//Instanciation du model
            $tdb = new AbonnementDB();
			//Récupération des données qui viennent du formulaire view/test/add.html (à créer)
            if(isset($_POST['valider']))//'valider' est le name du champs submit du formulaire add.html
            {
                extract($_POST);
                $data['ok'] = 0;
               $resultat=0;
                $ok = $tdb->addAbon($contrat,$date,$cumulAncien,$cumulNouveau,$resultat,$numero);
                $data['ok'] = $ok;
            
                return $this->liste();
            }
            
            else{
                return $this->view->load("abonnement/liste2");
            }
        }
        
        public function index(){
            return $this->view->load("abonnement/index");
        }

        public function getID($id){
            $data['test'] = $id;

            return $this->view->load("abonnement/get_id", $data);
        }
        
        public function get($id){
            //Instanciation du model
            $tdb = new  AbonnementDB();

            $data['test'] = $tdb->getAbonID($id);
			
            return $this->view->load("abonnement/get", $data);
        }
        public function getCompt($id){
            //Instanciation du model
            $tdb = new  AbonnementDB();

            $data['test'] = $tdb->getcomptID($id);
			
            return $this->view->load("abonnement/get", $data);
        }
        
		public function liste(){
            //Instanciation du model
            $tdb = new AbonnementDB();
			
            $data['tests'] = $tdb->listeAbon();
			
            return $this->view->load("abonnement/liste", $data);
        }
    
        public function liste2(){
            //Instanciation du model
            $tdb = new AbonnementDB();
			
            $data['tests'] = $tdb->listeNumCompt();
			
            return $this->view->load("abonnement/liste2", $data);
        }
	
	
		public function choix($id){
			//Instanciation du model
            $tdb = new AbonnementDB();
            //Supression
            $data['tests'] = $tdb->listeNumCompt();
			$data['test'] = $tdb->getcomptID($id);
			//chargement de la vue edit.html
            return $this->view->load("abonnement/liste2", $data);
        }

		public function update(){
			//Instanciation du model
            $tdb = new  AbonnementDB();
            if(isset($_POST['modifier'])){
                $data['ok']=0;
                extract($_POST);
                if(!empty($idAbonnement) && !empty($contrat) && !empty($cumulAncien) && !empty($cumulNouveau)) 
                {
                    $valeur=floatval($cumulAncien);
                   
                      if($cumulNouveau>=$valeur){
                          $resultat=$cumulNouveau-$valeur;
                    $ok = $tdb->updateAbon($idAbonnement,$contrat,$valeur,$cumulNouveau, $resultat);
                      return $this->liste();
                      }
                  
                else
                {
                    echo "Attention!! Le nouveau cumul doit etre superieur ou égale à l'ancien";
                }
            }
        }
            //appel de la methode liste du controller
        }

        public function delete($id){
            //Instanciation du model
            $tdb = new AbonnementDB();
			//Supression
			$tdb->deleteAbon($id);
			//Retour vers la liste
            return $this->liste();
        }
		
		public function edit($id){
			
            //Instanciation du model
            $tdb = new AbonnementDB();
			//Supression
			$data['test'] = $tdb->getAbonID($id);
			//chargement de la vue edit.html
            return $this->view->load("abonnement/edit", $data);
        }

       //fonction pour récupération des numeros de compteur
       public function listeNC(){
        //Instanciation du model
        $tdb = new AbonnementDB();
        
        $data['recup'] = $tdb->listeNumCompt();
        
        return $this->view->load("abonnement/addAbon", $data);
    }

    }
?>