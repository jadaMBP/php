<?php
/*==================================================
    MODELE MVC DEVELOPPE PAR Ngor SECK
    ngorsecka@gmail.com
    (+221) 77 - 433 - 97 - 16
    PERFECTIONNEZ CE MODEL ET FAITES MOI UN RETOUR
    POUR TOUTE MODIFICATION VISANT A AMELIORER
    CE MODELE.
    VOUS ETES LIBRE DE TOUTE UTILISATION.
  ===================================================*/
    //class
    class User extends Controller{

        public function __construct(){
            parent::__construct();
            require_once 'model/UserDB.php';
        }
        //methode ou url
        public function index(){
			//view
            return $this->view->load("user/index");
			
        }



        public function GetConnection(){
            //Instanciation du model
            $tdb = new  UserDB();
            if(isset($_POST['connexion']))//'valider' est le name du champs submit du formulaire add.html
            {
                extract($_POST);
                $data['ok'] = 0;
                
                    $ok = $tdb->connection($email,$password);
                    if($ok->rowCount()>0)
                    {
                    $data['ok'] = $ok;
                
                return $this->view->load("accueil/index", $data);
                     }

                     else{
                        return $this->view->load("user/index",$data);
                    }

            }
           

        }	
    }
?>