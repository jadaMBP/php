<?php
/* Smarty version 3.1.30, created on 2019-02-17 14:36:58
  from "C:\xampp\htdocs\projetphp\projetphp\view\abonnement\liste2.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c69637aec0404_06642720',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '60debb71d9c38cea324cd324915e9d1adb3c53cb' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetphp\\projetphp\\view\\abonnement\\liste2.php',
      1 => 1550410606,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c69637aec0404_06642720 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page liste</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}
		</style>
	</head>
	<body>
		
		<div class="nav navbar navbar-default navbar-fixed-top">
		<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		<div class="col-md-6 col-xs-6 col-md-6" style="margin-top:70px;">
			<div class="panel panel-primary">
				<div class="panel-heading">NUMEROS COMPTEUR DISPONIBLES</div>
				<div class="panel-body">
			
					<?php if (isset($_smarty_tpl->tpl_vars['tests']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['tests']->value != null) {?>
							<table class="table table-bordered table-stripped">
								<tr>
									
									<th>numero</th>
									
								</tr>
								<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
									<tr>
										
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
</td>
										
										
										<td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/choix/<?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
">Choisir </a></td>
									</tr>
								<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

							</table>
						<?php } else { ?>
							Liste vide
						<?php }?>
					<?php }?>
				</div>
				
			</div>
		</div>
		<!----------------formulaire abonnement------------------>

		<div class="col-md-6 col-xs-6 col-md-6" style="margin-top:70px;">
			<div class="panel panel-primary">
				<div class="panel-heading">FORMULAIRE D'ABONNEMENT</div>
				<div class="panel-body">
				<?php if (isset($_smarty_tpl->tpl_vars['ok']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['ok']->value != 0) {?>
							<div class="alert alert-success">Données ajoutées! votre numéro de compteur est : <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
 <?php }?> </div>
						<?php } else { ?>
							<div class="alert alert-danger">Erreur!! cumul Ancien et cumul Nouveau doivent être des chiffres</div>
						<?php }?>
					<?php }?>
					<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/add">
						<div class="form-group">
							<label class="control-label">Contrat</label>
							<input class="form-control" type="text" name="contrat" id="contrat" required/>
						</div>
						<div class="form-group">
								<label class="control-label">date</label>
								<input class="form-control" type="date" name="date" id="date" required/>
							</div>

							<div class="form-group">
							<label class="control-label">Cumul Ancien</label>
							 <h1> <select name="cumulAncien" id="cumulAncien" class="form-control">
								<option value=0> 0 </option>
							 </select> </h1>
						</div>

						<div class="form-group">
							<label class="control-label">Cumul Nouveau</label>
							 <h1> <select name="cumulNouveau" id="cumulNouveau" class="form-control">
								<option value=0> 0 </option>
							 </select> </h1>
						</div>

									<div class="form-group">
							<label class="control-label">Numero compteur</label>
							 <h1> <select name="numero" id="numero">
								<option > <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
 <?php }?> </option>
							 </select> </h1>
						</div>
					
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="valider" value="ENVOYER"/>
							
							<input class="btn btn-danger" type="reset" name="annuler" value="ANNULER"/>
							<a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste" class="btn btn-success" >AFFICHER</a>
							
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
<?php }
}
