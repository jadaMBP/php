<?php
/* Smarty version 3.1.30, created on 2019-02-17 15:50:49
  from "C:\xampp\htdocs\projetphp\projetphp\view\accueil\index.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c6974c9e099e0_31514102',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c270a003d69fa0e00637794e668118d98f8c9383' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetphp\\projetphp\\view\\accueil\\index.php',
      1 => 1550415045,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c6974c9e099e0_31514102 (Smarty_Internal_Template $_smarty_tpl) {
?>
<!doctype html>
<html lang="en">
	<head>
		<meta charset="UTF-8">
		<title>page d'accueil</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<!-- integration de javascript dans le moteur de rendu de vue Smarty -->
		
			<?php echo '<script'; ?>
 language=javascript>
			 function load_design() {
			   document.getElementById("design_js").style.color = "#40007d";
			 }
               
			<?php echo '</script'; ?>
>
		
		<style>
			
			
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}

            .panel-body {
                 background-color:#28afeb;
                 border:1px solid #9FC6FF;
                 padding:5px;
           /*arrondir les coins en haut à gauche et en bas à droite*/
           -moz-border-radius:10px 0;
            -webkit-border-radius:10px 0;
            border-radius:20px 0;
			
                }

				.panel-primary{
					border:1px solid #9FC6FF;
                 padding:5px;
           /*arrondir les coins en haut à gauche et en bas à droite*/
           -moz-border-radius:10px 0;
            -webkit-border-radius:10px 0;
            border-radius:20px 0;
			width:195px;
			margin-right:100px;
				}

				.panel-heading{
					-moz-border-radius:10px 0;
            -webkit-border-radius:10px 0;
            border-radius:20px 0;
				}

				
                   
				   .senelecbat{
					width:1200px;
						height:300px;
						margin-top:8px;
				   }

                   .logosenelec
				   {
                        width:1200px;
						height:300px;
						margin-top:8px;
				   }
					
					.woyofal{
						width:1200px;
						height:300px;
						margin-top:9px;
					}
				  .akilee{
					width:1200px;
						height:300px;
						margin-top:9px;
				}

		</style>
	</head>
	<body onload="load_design()">

		<div class="nav navbar navbar-default navbar-fixed-top">
		<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		
		<marquee behavior="Alternate" direction="">
			
			<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logosen2.jpg" class="logosenelec">
			<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/senelecbat.jpg" class="senelecbat"> 
		
		</marquee>

		<div class="col-md-10 col-xs-6 col-md-10" style="margin-top:2px;" >
		
		
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/woyofal.png" class="woyofal"> 
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/akilee.jpg" class="akilee"> 
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/lampe.jpg" class="akilee">
	</div>         


		

		

       
	</body>
</html>
<?php }
}
