<?php
/* Smarty version 3.1.30, created on 2019-02-12 16:43:11
  from "C:\xampp\htdocs\projetphp\projetphp\view\abonnement\liste.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c62e98fb86872_90708415',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'eae1a22fe795685ef5a93592259a2a5b6c8339b4' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetphp\\projetphp\\view\\abonnement\\liste.html',
      1 => 1549986123,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c62e98fb86872_90708415 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page liste</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
		</style>
	</head>
	<body>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
			<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
">Accueil</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste">Gestion des Compteurs</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste">Gestion des Abonnements</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste">Gestion des factures</a></li>
			</ul>
		</div>
		<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:150px;">
			<div class="panel panel-info">
				<div class="panel-heading">BIENVENUE A VOTRE MODELE MVC</div>
				<div class="panel-body">
					<div class="alert alert-success" style="font-size:18px; text-align:justify;">
						Merci, l'équipe samanemvc vous remercie :) : 
						je vous ai préparé un CRUD qui marche, il suffit tout simplement d'importer
						la base de données qui se trouve dans le dossier view puis test (view/test);
						cette base s'appelle samane_test.sql et elle comporte une seule table nommée test.
						ça vous sera très utile j'espère.
						<br/>Et surtout noubliez pas de configurer votre base de données : ou? Dans le dossier config
						puis éditez le fichier database.php. Mettez à on l'etat de la base puis cliquez sur le menu <b>Menu page test liste</b>! Bon code!!!!  :)
					</div>
					<?php if (isset($_smarty_tpl->tpl_vars['tests']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['tests']->value != null) {?>
							<table class="table table-bordered table-stripped">
								<tr>
									<th>Identifiant</th>
									<th>Contrat</th>
									<th>Date</th>
									<th>Cumul Ancien</th>
									<th>Cumul Nouveau</th>
									<th>Numero Compteur</th>
									
								</tr>
								<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
									<tr>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['contrat'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['date'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['cumulAncien'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['cumulNouveau'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
</td>
										
										<td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/delete/<?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
">Supprimer</a></td>
										<td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/edit/<?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
">Editer</a></td>
									</tr>
								<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

							</table>
						<?php } else { ?>
							Liste vide
						<?php }?>
					<?php }?>
				</div>
				<a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/add">Ajout d'un Abonnement</a>
			</div>
		</div>
		
	</body>
</html>
<?php }
}
