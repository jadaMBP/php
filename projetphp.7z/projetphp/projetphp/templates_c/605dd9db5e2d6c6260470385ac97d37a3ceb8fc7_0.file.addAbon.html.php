<?php
/* Smarty version 3.1.30, created on 2019-02-13 16:10:26
  from "C:\xampp\htdocs\projetphp\projetphp\view\abonnement\addAbon.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c643362530130_40611816',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '605dd9db5e2d6c6260470385ac97d37a3ceb8fc7' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetphp\\projetphp\\view\\abonnement\\addAbon.html',
      1 => 1550070625,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c643362530130_40611816 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page get id</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
		</style>
		 
	</head>
	<body>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
			<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
">Accueil</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste">Gestion des compteurs</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste">Gestion des Abonnements</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste">Gestion des facturations</a></li>
			</ul>
		</div>
		<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:150px;">
			<div class="panel panel-info">
				<div class="panel-heading">BIENVENUE A VOTRE MODELE MVC</div>
				<div class="panel-body">
					<?php if (isset($_smarty_tpl->tpl_vars['ok']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['ok']->value != 0) {?>
							<div class="alert alert-success">Données ajoutées! votre numéro de compteur est : 1 </div>
						<?php } else { ?>
							<div class="alert alert-danger">Erreur!</div>
						<?php }?>
					<?php }?>
					<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/add">
						<div class="form-group">
							<label class="control-label">Contrat</label>
							<input class="form-control" type="text" name="contrat" id="contrat"/>
						</div>
						<div class="form-group">
								<label class="control-label">date</label>
								<input class="form-control" type="date" name="date" id="date"/>
							</div>
							<div class="form-group">
									<label class="control-label">cumul Ancien</label>
									<input class="form-control" type="text" name="cumulAncien" id="cumulAncien"/>
								</div>
								<div class="form-group">
										<label class="control-label">cumul nouveau</label>
										<input class="form-control" type="text" name="cumulNouveau" id="cumulNouveau"/>
									</div>
									<div class="form-group">
											<label class="control-label">Numero de compteur</label>
											
											<?php if (isset($_smarty_tpl->tpl_vars['recup']->value)) {?>
											<?php if ($_smarty_tpl->tpl_vars['recup']->value != null) {?>
											<select name="numero" id="numero"></select>
											<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['recup']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
											<option><?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
</option></select>
											<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

										
										<?php } else { ?>
										Liste vide
									<?php }?>
								<?php }?>
								
										</div>
					
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="valider" value="ENVOYER"/>
	                        <input class="btn btn-danger" type="reset" name="annuler" value="ANNULER"/>
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html><?php }
}
