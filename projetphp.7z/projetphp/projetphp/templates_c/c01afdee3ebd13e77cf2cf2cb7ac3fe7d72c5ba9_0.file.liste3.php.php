<?php
/* Smarty version 3.1.30, created on 2019-02-17 14:07:42
  from "C:\xampp\htdocs\projetphp\projetphp\view\facture\liste3.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c695c9ec3ab34_81763640',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'c01afdee3ebd13e77cf2cf2cb7ac3fe7d72c5ba9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetphp\\projetphp\\view\\facture\\liste3.php',
      1 => 1550408857,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c695c9ec3ab34_81763640 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page liste</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}
		</style>
	</head>
	<body>
		
		<div class="nav navbar navbar-default navbar-fixed-top">
		<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		<div class="col-md-6 col-xs-6 col-md-6" style="margin-top:70px;">
			<div class="panel panel-primary">
				<div class="panel-heading">LISTE DES ABONNEMENTS</div>
				<div class="panel-body">
					
				<?php if (isset($_smarty_tpl->tpl_vars['tests']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['tests']->value != null) {?>
							<table class="table table-bordered table-stripped">
								<tr>
									<th>Identifiant</th>
									<th>Contrat</th>
									<th>Action</th>
								
									
								</tr>
								<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
									<tr>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['contrat'];?>
</td>
										
										
										
										<td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/choix/<?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
">Choisir</a></td>
									</tr>
								<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

							</table>
						<?php } else { ?>
							Liste vide
						<?php }?>
					<?php }?>
				</div>
				
			</div>
		</div>
		<!--------------formulaire facture----------->

		<div class="col-md-6 col-xs-6 col-md-6" style="margin-top:70px;">
			<div class="panel panel-primary">
				<div class="panel-heading">FACTURE </div>
				<div class="panel-body">
					<?php if (isset($_smarty_tpl->tpl_vars['ok']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['ok']->value != 0) {?>
							<div class="alert alert-success">Données ajoutées!</div>
						<?php } else { ?>
							<div class="alert alert-danger">Erreur!</div>
						<?php }?>
					<?php }?>
					<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/add">
						<div class="form-group">
							<label class="control-label">Mois</label>
							<h3> <select name="mois" id="mois">
									<option > Janvier</option>
									<option > Fevrier</option>
									<option > Mars</option>
									<option > Avril</option>
									<option > Mai</option>
									<option > Juin</option>
									<option > Juillet</option>
									<option > Août</option>
									<option > Septembre</option>
									<option > Octobre</option>
									<option > Novembre</option>
									<option > Decembre</option>
								 </select> </h3>
							
						</div>
						<div class="form-group">
								<label class="control-label">Consommation</label>
								<select class="form-control" type="float" name="consommation" id="consommation" >
								<option> <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['resultat'];?>
 <?php }?> </option>
		</select>
							</div>
							<div class="form-group">
									<label class="control-label">Prix</label>
									<input class="form-control" type="number" name="prix" id="prix" required/>
								</div>
								<div class="form-group">
										<label class="control-label">Réglement</label>
										<h3><select class="form-control" name="reglement" id="reglement">
										
										<option value="oui">oui</option>
											<option value="non"> non</option>
												
											
										</select></h3>
									</div>
									<div class="form-group">
								<label class="control-label"> ID Abonnement</label>
								 <h1> <select name="idAbonnement" id="idAbonnement">
								
								<option > <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
 <?php }?> </option>
							 </select> </h1>
							</div>
					
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="valider" value="ENVOYER"/>
							<input class="btn btn-danger" type="reset" name="annuler" value="ANNULER"/>
							<a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste" class="btn btn-success">AFFICHER</a>
						</div>
					</form>
				</div>
			</div>
		</div>

        

	</body>
</html>
<?php }
}
