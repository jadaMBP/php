<?php
/* Smarty version 3.1.30, created on 2019-02-14 00:38:40
  from "C:\xamppp\htdocs\projetphp\projetphp\view\facture\addFact.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c64aa80a2c3a3_57598079',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '96cf500f59c8e27660b597047908c034cb66c36b' => 
    array (
      0 => 'C:\\xamppp\\htdocs\\projetphp\\projetphp\\view\\facture\\addFact.php',
      1 => 1550087190,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c64aa80a2c3a3_57598079 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page get id</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
		</style>
		 
	</head>
	<body>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
			<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
">Accueil</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste">Gestion des compteurs</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2">Gestion des Abonnements</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste">Gestion des facturations</a></li>
			</ul>
		</div>
		<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:150px;">
			<div class="panel panel-info">
				<div class="panel-heading">BIENVENUE A VOTRE MODELE MVC</div>
				<div class="panel-body">
					<?php if (isset($_smarty_tpl->tpl_vars['ok']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['ok']->value != 0) {?>
							<div class="alert alert-success">Données ajoutées!</div>
						<?php } else { ?>
							<div class="alert alert-danger">Erreur!</div>
						<?php }?>
					<?php }?>
					<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/add">
						<div class="form-group">
							<label class="control-label">Mois</label>
							<h3> <select name="mois" id="mois">
									<option > Janvier</option>
									<option > Février</option>
									<option > Mars</option>
									<option > Avril</option>
									<option > Mai</option>
									<option > Juin</option>
									<option > Juillet</option>
									<option > Août</option>
									<option > Septembre</option>
									<option > Octobre</option>
									<option > Novembre</option>
									<option > Decembre</option>
								 </select> </h3>
							
						</div>
						<div class="form-group">
								<label class="control-label">Consommation</label>
								<input class="form-control" type="float" name="consommation" id="consommation"/>
							</div>
							<div class="form-group">
									<label class="control-label">Prix</label>
									<input class="form-control" type="text" name="prix" id="prix"/>
								</div>
								<div class="form-group">
										<label class="control-label">Règlement</label>
										<input class="form-control" type="text" name="reglement" id="reglement"/>
									</div>
									<div class="form-group">
								<label class="control-label"> ID Abonnement</label>
								 <h1> <select name="idAbonnement" id="idAbonnement">
								
								<option > <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
 <?php }?> </option>
							 </select> </h1>
							</div>
					
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="valider" value="ENVOYER"/>
							<input class="btn btn-danger" type="reset" name="annuler" value="ANNULER"/>
							<a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste" class="btn btn-success">AFFICHER</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html><?php }
}
