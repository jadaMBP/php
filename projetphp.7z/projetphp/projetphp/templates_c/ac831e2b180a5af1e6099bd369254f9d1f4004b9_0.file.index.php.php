<?php
/* Smarty version 3.1.30, created on 2019-02-17 14:49:47
  from "C:\xampp\htdocs\projetphp\projetphp\view\user\index.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c69667ba40d66_84817671',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ac831e2b180a5af1e6099bd369254f9d1f4004b9' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetphp\\projetphp\\view\\user\\index.php',
      1 => 1550411384,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c69667ba40d66_84817671 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page d'accueil</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}

			.logosenelec{
				margin-left:10px;
				margin-top:50px;
				width:65px;
				 height:65px;
				

			}             
			 .ic_user{

				 margin-left:250px;
				 width:150px;
				 height:150px;
			 }

		</style>
	</head>
	<body>
		
	<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logosen2.jpg" class="logosenelec">

	
		<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:50px;">
			<div class="panel panel-info">
				<div class="panel-heading">BIENVENUE </div>
				<div class="panel-body">
				
				<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/user.png" class="ic_user">

				<?php if (isset($_smarty_tpl->tpl_vars['ok']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['ok']->value != 0) {?>
							<div class="alert alert-success">  </div>
						<?php } else { ?>
							<div class="alert alert-danger"> email ou mot de pass incorrecte</div>
						<?php }?>
					<?php }?>
					<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
User/GetConnection">
						

						<div class="form-group">
									<label class="control-label">EMAIL</label>
									<input class="form-control" type="email" name="email" id="email" required/>
						</div>

                  			  <div class="form-group">
									<label class="control-label">PASSWORD</label>
									<input class="form-control" type="password" name="password" id="password" required/>
								</div>

						  
								<div class="form-group">
							<input class="btn btn-success" type="submit" name="connexion" value="connexion"/>
							</div>
							
						
					</form>
				</div>
			</div>
		</div>
		
	</body>
</html>
		
<?php }
}
