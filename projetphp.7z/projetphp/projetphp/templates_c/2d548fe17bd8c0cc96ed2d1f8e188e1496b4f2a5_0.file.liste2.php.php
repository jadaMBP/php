<?php
/* Smarty version 3.1.30, created on 2019-02-14 14:28:28
  from "C:\xamppp\htdocs\projetphp\projetphp\view\abonnement\liste2.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c656cfcd98682_56251729',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '2d548fe17bd8c0cc96ed2d1f8e188e1496b4f2a5' => 
    array (
      0 => 'C:\\xamppp\\htdocs\\projetphp\\projetphp\\view\\abonnement\\liste2.php',
      1 => 1550150906,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c656cfcd98682_56251729 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page liste</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
		</style>
	</head>
	<body>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
			<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
">Accueil</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste">Gestion des Compteurs</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2">Gestion des Abonnements</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste3">Gestion des factures</a></li>
			</ul>
		</div>
		<div class="col-md-6 col-xs-6 col-md-6" style="margin-top:150px;">
			<div class="panel panel-primary">
				<div class="panel-heading">NUMERO COMPTEUR DISPONIBLE</div>
				<div class="panel-body">
			
					<?php if (isset($_smarty_tpl->tpl_vars['tests']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['tests']->value != null) {?>
							<table class="table table-bordered table-stripped">
								<tr>
									
									<th>numero</th>
									
								</tr>
								<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
									<tr>
										
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
</td>
										
										
										<td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/choix/<?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
">Choisir </a></td>
									</tr>
								<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

							</table>
						<?php } else { ?>
							Liste vide
						<?php }?>
					<?php }?>
				</div>
				
			</div>
		</div>
		<!----------------formulaire abonnement------------------>

		<div class="col-md-6 col-xs-6 col-md-6" style="margin-top:70px;">
			<div class="panel panel-primary">
				<div class="panel-heading">FORMULAIRE ABONNEMENT</div>
				<div class="panel-body">
				<?php if (isset($_smarty_tpl->tpl_vars['ok']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['ok']->value != 0) {?>
							<div class="alert alert-success">Données ajoutées! votre numéro de compteur est : <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
 <?php }?> </div>
						<?php } else { ?>
							<div class="alert alert-danger">Erreur!! cumil Ancien et cumul Nouveau sont des chiffres</div>
						<?php }?>
					<?php }?>
					<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/add">
						<div class="form-group">
							<label class="control-label">Contrat</label>
							<input class="form-control" type="text" name="contrat" id="contrat" required/>
						</div>
						<div class="form-group">
								<label class="control-label">date</label>
								<input class="form-control" type="date" name="date" id="date"/>
							</div>
							<div class="form-group">
									<label class="control-label">cumul Ancien</label>
									<input class="form-control" type="number" name="cumulAncien" id="cumulAncien" required/>
								</div>
								<div class="form-group">
										<label class="control-label">cumul nouveau</label>
										<input class="form-control" type="number" name="cumulNouveau" id="cumulNouveau" required/>
									</div>
									<div class="form-group">

							<label class="control-label">Numero compteur</label>
							 <h1> <select name="numero" id="numero">
								<option > <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
 <?php }?> </option>
							 </select> </h1>
						</div>
					
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="valider" value="ENVOYER"/>
							
							<input class="btn btn-danger" type="reset" name="annuler" value="ANNULER"/>
							<a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste" class="btn btn-success" >AFFICHER</a>
							
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html>
<?php }
}
