<?php
/* Smarty version 3.1.30, created on 2019-02-12 19:59:22
  from "C:\xamppp\htdocs\projetphp\projetphp\view\abonnement\edit.html" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c63178a7339a1_93076597',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'd5dcdad5f830d7cc67a51fa489ad32b474267056' => 
    array (
      0 => 'C:\\xamppp\\htdocs\\projetphp\\projetphp\\view\\abonnement\\edit.html',
      1 => 1549997959,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c63178a7339a1_93076597 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page get id</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
		</style>
	</head>
	<body>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
			<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste">Gestion des Compteurs</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste">Gestion des Abonnements</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste">Gestion des factures</a></li>
			</ul>
		</div>
		<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:150px;">
			<div class="panel panel-info">
				<div class="panel-heading">BIENVENUE A VOTRE MODELE MVC</div>
				<div class="panel-body">
					<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/update">
						<div class="form-group">
							<label class="control-label">ID Abonnement </label><h1><select name="id" id="id" visibility="hibben">
									<option><?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['id'];?>
 <?php }?></option>"
							</select></h1>
                                         
						</div>
						<div class="form-group">
							<label class="control-label">contrat</label>
							<input class="form-control" type="text" name="contrat" id="contrat" value="<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['contrat'];?>
 <?php }?>"/>
						</div>
						<div class="form-group">
								<label class="control-label">date</label>
							<h1><select name="date" id="date" >
								<option>	<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['date'];?>
 <?php }?></option>
								
								</select></h1>
							</div>
						<div class="form-group">
								<label class="control-label">cumul Ancien</label>
								<input class="form-control" type="float" name="cumulan" id="cumulan" value="<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['cumulAnc'];?>
 <?php }?>"/>
							</div>
							<div class="form-group">
									<label class="control-label">cumul Nouveau</label>
									<input class="form-control" type="text" name="cumulnew" id="cumulnew" value="<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['cumulNew'];?>
 <?php }?>"/>
								</div>
								<div class="form-group">
										<label class="control-label">numero Compteur</label>
										<input class="form-control" type="text" name="numero" id="numero" value="<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['numeroCompteur'];?>
 <?php }?>"/>
									</div>
						
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="modifier" value="Modifier"/>
							<a class="btn btn-primary" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste">Retour</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html><?php }
}
