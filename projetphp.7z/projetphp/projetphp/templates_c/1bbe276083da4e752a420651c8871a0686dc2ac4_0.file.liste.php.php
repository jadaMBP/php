<?php
/* Smarty version 3.1.30, created on 2019-02-14 01:55:01
  from "C:\xamppp\htdocs\projetphp\projetphp\view\compteur\liste.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c64bc6577c367_85366292',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '1bbe276083da4e752a420651c8871a0686dc2ac4' => 
    array (
      0 => 'C:\\xamppp\\htdocs\\projetphp\\projetphp\\view\\compteur\\liste.php',
      1 => 1550105697,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c64bc6577c367_85366292 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page liste</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
		</style>
	</head>
	<body>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
			<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
">Accueil</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste">Gestion des Compteurs</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2">Gestion des Abonnements</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste3">Gestion des factures</a></li>
			</ul>
		</div>
		<div class="col-md-9 col-xs-16 col-md-15" style="margin-top:110px;">
			<div class="panel panel-primary">
				<div class="panel-heading">AFFICHAGE DES COMPTEURS</div>
				<div class="panel-body">
				
					<?php if (isset($_smarty_tpl->tpl_vars['tests']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['tests']->value != null) {?>
							<table class="table table-bordered table-stripped">
								<tr>
								<th>NUMERO</th>
									<th>ACTION</th>
									
									
								</tr>
								<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
									<tr>
										
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
</td>
										
										<td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/delete/<?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
">Supprimer</a></td>
							
									</tr>
								<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

							</table>
						<?php } else { ?>
							Liste vide
						<?php }?>
					<?php }?>
				</div>
				<a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/add" class="panel-heading">Ajout d'un Compteur</a>
			</div>
		</div>
		<!-----------------------formulaire ajout numero compteur----->

	</body>
</html>
<?php }
}
