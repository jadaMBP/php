<?php
/* Smarty version 3.1.30, created on 2019-02-17 20:52:39
  from "C:\xampp\htdocs\projetphp\projetphp\view\facture\edit.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c69bb879ea966_25250666',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'a53f8fc2755877432a8097ff1f64cd9c98eab6c3' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetphp\\projetphp\\view\\facture\\edit.php',
      1 => 1550433148,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c69bb879ea966_25250666 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page get id</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #348ba5;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}
		</style>
	</head>
	<body>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
		<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		<div class="col-md-9 col-xs-12 col-md-offset-1" style="margin-top:60px;">
			<div class="panel panel-primary">
				<div class="panel-heading">MODIFICATION</div>
				<div class="panel-body">
					<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/update">
						<div class="form-group">
							<label class="control-label">ID Facture</label>
							 <h1> <select name="idFacture" id="idFacture">
								<option > <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['idFacture'];?>
 <?php }?> </option>
							 </select> </h1>
						</div>
						
                        <div class="form-group">
								<label class="control-label">mois</label>
								 <h1> <select name="mois" id="mois">
									<option value=""> <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['mois'];?>
 <?php }?> </option>
								 </select> </h1>
							</div>
							<div class="form-group">
								<label class="control-label">Consommation</label>
								<select class="form-control" type="number" step="any" name="consommation" id="consommation">
                                 <option value="<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['consommation'];?>
 <?php }?>"> <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['consommation'];?>
 <?php }?></option>
								</select> 
							</div>
							<div class="form-group">
									<label class="control-label">prix</label>
									<input class="form-control" type="int" name="prix" id="prix" value="<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['prix'];?>
 <?php }?>"/>
								</div>
								<div class="form-group">
									<label class="control-label">reglement</label>
									<h1> <select name="reglement" id="reglement">
									<option value="oui">oui</option>
									<option value="non">non</option>
								 </select> </h1>
								</div>
								<div class="form-group">
								<label class="control-label">ID Abonnement</label>
								 <h1> <select name="idAbonnement" id="idAbonnement">
									<option value=""> <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
 <?php }?> </option>
								 </select> </h1>
							</div>

						
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="modifier" value="Modifier"/>
							<a class="btn btn-primary" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste">Retour</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html><?php }
}
