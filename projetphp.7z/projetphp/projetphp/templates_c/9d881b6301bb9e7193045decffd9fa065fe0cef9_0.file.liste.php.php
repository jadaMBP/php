<?php
/* Smarty version 3.1.30, created on 2019-02-14 01:20:58
  from "C:\xamppp\htdocs\projetphp\projetphp\view\abonnement\liste.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c64b46ae86e56_79631606',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '9d881b6301bb9e7193045decffd9fa065fe0cef9' => 
    array (
      0 => 'C:\\xamppp\\htdocs\\projetphp\\projetphp\\view\\abonnement\\liste.php',
      1 => 1550103519,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c64b46ae86e56_79631606 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page liste</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #40007d;
			}
		</style>
	</head>
	<body>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
			<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
">Accueil</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste">Gestion des Compteurs</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2">Gestion des Abonnements</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste3">Gestion des factures</a></li>
			</ul>
		</div>
		<div class="col-md-8 col-xs-12 col-md-offset-2" style="margin-top:60px;">
			<div class="panel panel-primary">
				<div class="panel-heading">AFFICHAGE DES ABONNEMENTS</div>
				<div class="panel-body">
					
					<?php if (isset($_smarty_tpl->tpl_vars['tests']->value)) {?>
						<?php if ($_smarty_tpl->tpl_vars['tests']->value != null) {?>
							<table class="table table-bordered table-stripped">
								<tr  >
									<th >Identifiant</th>
									<th>Contrat</th>
									<th>Date</th>
									<th>Cumul Ancien</th>
									<th>Cumul Nouveau</th>
									<th>Numero Compteur</th>
									<th>ACTION</th>
									<th>ACTION</th>
									
								</tr>
								<?php
$_from = $_smarty_tpl->smarty->ext->_foreach->init($_smarty_tpl, $_smarty_tpl->tpl_vars['tests']->value, 'test');
if ($_from !== null) {
foreach ($_from as $_smarty_tpl->tpl_vars['test']->value) {
?>
									<tr>
										<td ><?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['contrat'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['date'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['cumulAncien'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['cumulNouveau'];?>
</td>
										<td><?php echo $_smarty_tpl->tpl_vars['test']->value['numero'];?>
</td>
										
										<td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/delete/<?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
">Supprimer</a></td>
										<td><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/edit/<?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
">Editer</a></td>
									</tr>
								<?php
}
}
$_smarty_tpl->smarty->ext->_foreach->restore($_smarty_tpl);
?>

							</table>
						<?php } else { ?>
							Liste vide
						<?php }?>
					<?php }?>
				</div>
				<a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2" class="btn btn-success">RETOUR</a>
			</div>
		</div>
		
	</body>
</html>
<?php }
}
