<?php
/* Smarty version 3.1.30, created on 2019-02-14 14:43:57
  from "C:\xamppp\htdocs\projetphp\projetphp\view\facture\edit.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c65709db03198_95691042',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    '7d76a5b37b9ddca6cc1d346ebccecfbd17dd20e2' => 
    array (
      0 => 'C:\\xamppp\\htdocs\\projetphp\\projetphp\\view\\facture\\edit.php',
      1 => 1550151617,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c65709db03198_95691042 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page get id</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #348ba5;
			}
		</style>
	</head>
	<body>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
			<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste">Gestion des Compteurs</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2">Gestion des Abonnements</a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste3">Gestion des factures</a></li>
			</ul>
		</div>
		<div class="col-md-9 col-xs-12 col-md-offset-1" style="margin-top:60px;">
			<div class="panel panel-primary">
				<div class="panel-heading">MODIFICATION</div>
				<div class="panel-body">
					<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/update">
						<div class="form-group">
							<label class="control-label">ID Facture</label>
							 <h1> <select name="idFacture" id="idFacture">
								<option > <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['idFacture'];?>
 <?php }?> </option>
							 </select> </h1>
						</div>
						
                        <div class="form-group">
								<label class="control-label">mois</label>
								 <h1> <select name="mois" id="mois">
									<option value=""> <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['mois'];?>
 <?php }?> </option>
								 </select> </h1>
							</div>
                        <div class="form-group">
								<label class="control-label">Consommation</label>
								<input class="form-control" type="float" name="consommation" id="consommation" value="<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['consommation'];?>
 <?php }?>"/>
							</div>
							<div class="form-group">
									<label class="control-label">prix</label>
									<input class="form-control" type="int" name="prix" id="prix" value="<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['prix'];?>
 <?php }?>"/>
								</div>
								<div class="form-group">
									<label class="control-label">reglement</label>
									<h1> <select name="reglement" id="reglement">
									<option value="oui">oui</option>
									<option value="oui">non</option>
								 </select> </h1>
								</div>
								<div class="form-group">
								<label class="control-label">ID Abonnement</label>
								 <h1> <select name="idAbonnement" id="idAbonnement">
									<option value=""> <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
 <?php }?> </option>
								 </select> </h1>
							</div>

						
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="modifier" value="Modifier"/>
							<a class="btn btn-primary" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste3">Retour</a>
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html><?php }
}
