<?php
/* Smarty version 3.1.30, created on 2019-02-17 19:21:37
  from "C:\xampp\htdocs\projetphp\projetphp\view\abonnement\edit.php" */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '3.1.30',
  'unifunc' => 'content_5c69a6318e6165_27413032',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'feaf90e0b9044a229f379b9a34b843cd13a6b04c' => 
    array (
      0 => 'C:\\xampp\\htdocs\\projetphp\\projetphp\\view\\abonnement\\edit.php',
      1 => 1550426025,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_5c69a6318e6165_27413032 (Smarty_Internal_Template $_smarty_tpl) {
?>
<html>
	<head>
		<meta charset="UTF-8">
		<title>page Modification</title>
		<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/bootstrap.min.css"/>
		<link type="text/css" rel="stylesheet" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/css/samane.css"/>
		<style>
			h1{ 
				color: #348ba5;
			}
			.navbar-default{
				background-color: #424777;
			}
			.a{
				color : #40007d;
			}
		</style>
	</head>
	<body>
		<img src="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
public/image/logo.jpg" class="resize" />
		<div class="nav navbar navbar-default navbar-fixed-top">
		<ul class="nav navbar-nav">
				<!-- l'appel de <?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
 vous permet de recupérer le chemin de votre site web  -->
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Accueil/index"><font color="#c89cc0" size="5px" face="Algerian">Accueil</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Compteur/liste" ><font color="#c89cc0" size="5px" face="Algerian">Gestion des Compteurs</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste2"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des Abonnements</font></a></li>
				<li><a href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Facture/liste3"><font color="#c89cc0" size="5px" face="Algerian" >Gestion des factures</font></a></li>
			</ul>
		</div>
		<div class="col-md-9 col-xs-12 col-md-offset-1" style="margin-top:60px;">
			<div class="panel panel-primary">
				<div class="panel-heading">MODIFICATION</div>
				<div class="panel-body">
			
					<form method="post" action="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/update">
						<div class="form-group">
							<label class="control-label">ID abonnement</label>
							 <h1> <select name="idAbonnement" id="idAbonnement">
								<option > <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['idAbonnement'];?>
 <?php }?> </option>
							 </select> </h1>
						</div>
						<div class="form-group">
							<label class="control-label">Contrat</label>
							<input class="form-control" type="text" name="contrat" id="contrat" value="<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['contrat'];?>
 <?php }?>"/>
						</div>
                        <div class="form-group">
								<label class="control-label">date d'abonnement</label>
								 <h1> <select name="date" id="date">
									<option value=""> <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['date'];?>
 <?php }?> </option>
								
								 </select> </h1>
							</div>
                        <div class="form-group">
								<label class="control-label">Cumul Ancien</label>
								<select class="form-control" type="number" step="any" name="cumulAncien" id="cumulAncien">
                                 <option value="<?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['cumulNouveau'];?>
 <?php }?>"> <?php if (isset($_smarty_tpl->tpl_vars['test']->value)) {?> <?php echo $_smarty_tpl->tpl_vars['test']->value['cumulNouveau'];?>
 <?php }?></option>
								</select> 
							</div>
							<div class="form-group">
									<label class="control-label">CumulNouveau</label>
									<input class="form-control" type="number" step="any" name="cumulNouveau" id="cumulNouveau" placeholder="Ecrire le nouveau cumul" />
								</div>
								

						
						<div class="form-group">
							<input class="btn btn-success" type="submit" name="modifier" value="Modifier"/>
							<a class="btn btn-primary" href="<?php echo $_smarty_tpl->tpl_vars['url_base']->value;?>
Abonnement/liste">Retour</a>
							
						</div>
					</form>
				</div>
			</div>
		</div>
	</body>
</html><?php }
}
