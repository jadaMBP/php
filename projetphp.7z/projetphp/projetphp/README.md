:thumbsup:
```
Name
```
## samanemvc
```
author
```
## Ngor SECK
```
Language
```
## PHP 
```
Version
```
## MVC version 1.2
```
?
```
## SamaneMVC is a PHP framework
```
Email
```
:email:
## ngorsecka@gmail.com
## samanemvc@gmail.com
```
composer command line
```
###### composer create-project samane/samanemvc your_project_name
:white_check_mark:
